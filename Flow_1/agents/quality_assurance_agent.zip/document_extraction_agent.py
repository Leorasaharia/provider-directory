# agents/document_extraction_agent.py
import os
import json
from typing import List, Optional

from models import ProviderInput

try:
    import google.generativeai as genai
except ImportError:
    genai = None


class DocumentExtractionAgent:
    """
    Uses Gemini to extract structured provider records from a PDF.

    Flow:
    - Input: raw PDF bytes (scanned roster, credential packet, etc.)
    - Gemini reads the PDF and returns JSON array of providers with fields:
      name, npi (optional), mobile_no, address, speciality, member_impact.
    - We convert that JSON into List[ProviderInput] to feed Flow-1.
    """

    def __init__(self) -> None:
        self._llm_ready = False
        self._model = None

        api_key = os.getenv("GEMINI_API_KEY")
        if api_key and genai is not None:
            try:
                genai.configure(api_key=api_key)
                # Vision-capable model for document understanding
                self._model = genai.GenerativeModel("gemini-flash-2.5")
                self._llm_ready = True
                print("[DocumentExtractionAgent] Gemini configured successfully.")
            except Exception as e:
                print(f"[DocumentExtractionAgent] Failed to configure Gemini: {e}")
        else:
            if genai is None:
                print("[DocumentExtractionAgent] google-generativeai not installed; PDF extraction disabled.")
            else:
                print("[DocumentExtractionAgent] GEMINI_API_KEY not set; PDF extraction disabled.")

    def extract_providers_from_pdf(self, pdf_bytes: bytes) -> List[ProviderInput]:
        """
        Main entrypoint:
        - Returns a list of ProviderInput extracted from the PDF.
        - If LLM is not ready or something fails, returns [].
        """
        if not self._llm_ready or not self._model:
            print("[DocumentExtractionAgent] LLM not ready – returning empty list.")
            return []

        prompt = """
You are helping a healthcare payer's Provider Data Management team clean up provider directories.

You will be given a PDF containing provider information such as rosters, credential forms,
or scanned documents. Your task is to extract a structured list of individual providers.

Return ONLY valid JSON. The JSON MUST be an array of objects, each with the fields:
- "name": string (full provider name; required)
- "npi": string (NPI number if present; otherwise "" as empty string)
- "mobile_no": string (phone number; can be office phone)
- "address": string (full practice address as one line)
- "speciality": string (provider speciality or primary taxonomy; use "" if unclear)
- "member_impact": integer from 1 to 5 (guess based on wording: 5 = very important/high volume, 1 = low)

Example of the JSON shape (do NOT include comments):

[
  {
    "name": "Dr Jane Doe",
    "npi": "1760429882",
    "mobile_no": "+1-555-123-4567",
    "address": "123 Main St, Springfield, IL 62704",
    "speciality": "Cardiology",
    "member_impact": 5
  }
]

Return ONLY the JSON. No explanations, no extra text.
""".strip()

        try:
            response = self._model.generate_content(
                [
                    {
                        "mime_type": "application/pdf",
                        "data": pdf_bytes,
                    },
                    prompt,
                ]
            )
            text = getattr(response, "text", None)
            if not text:
                print("[DocumentExtractionAgent] Empty response from Gemini.")
                return []

            json_str = self._extract_json(text)
            if not json_str:
                print("[DocumentExtractionAgent] Could not isolate JSON in LLM response.")
                return []

            raw_list = json.loads(json_str)
            if not isinstance(raw_list, list):
                print("[DocumentExtractionAgent] LLM JSON is not a list.")
                return []

            providers: List[ProviderInput] = []
            for item in raw_list:
                if not isinstance(item, dict):
                    continue

                name = (item.get("name") or "").strip()
                if not name:
                    # Skip entries without a name
                    continue

                npi = (item.get("npi") or "").strip()
                mobile = (item.get("mobile_no") or "").strip()
                addr = (item.get("address") or "").strip()
                spec = (item.get("speciality") or "").strip()
                try:
                    impact = int(item.get("member_impact", 3))
                except Exception:
                    impact = 3

                providers.append(
                    ProviderInput(
                        name=name,
                        npi=npi,
                        mobile_no=mobile,
                        address=addr,
                        speciality=spec,
                        member_impact=impact,
                    )
                )

            return providers
        except Exception as e:
            print(f"[DocumentExtractionAgent] Error calling Gemini for PDF: {e}")
            return []

    def _extract_json(self, text: str) -> Optional[str]:
        """
        Extract the JSON part from the LLM response text.
        Handles cases like ```json ...``` or extra commentary.
        """
        text = text.strip()

        # Remove Markdown fences if present
        if text.startswith("```"):
            # e.g. ```json\n...\n```
            # strip the first line and the last ```
            lines = text.splitlines()
            # drop first line like ```json
            if lines and lines[0].startswith("```"):
                lines = lines[1:]
            # drop last line if it's ```
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            text = "\n".join(lines).strip()

        # Try to find the first '[' and last ']'
        start = text.find("[")
        end = text.rfind("]")
        if start == -1 or end == -1 or end <= start:
            return None

        return text[start : end + 1]
