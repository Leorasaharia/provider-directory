# agents/llm_explanation_agent.py
import os
from typing import Optional

from models import ProviderReport

try:
    import google.generativeai as genai
except ImportError:
    genai = None


class LLMExplanationAgent:
    """
    Uses an LLM (Gemini) to generate a short explanation for a ProviderReport:
    - Why is this provider flagged?
    - What should a human reviewer do next?

    If Gemini is not configured, falls back to a rule-based explanation.
    """

    def __init__(self) -> None:
        self._llm_ready = False
        self._model = None

        api_key = os.getenv("GEMINI_API_KEY")
        if api_key and genai is not None:
            try:
                genai.configure(api_key=api_key)
                # Model for reasoning + explanations
                self._model = genai.GenerativeModel("gemini-flash-2.5")
                self._llm_ready = True
                print("[LLMExplanationAgent] Gemini LLM configured successfully.")
            except Exception as e:
                print(f"[LLMExplanationAgent] Failed to configure Gemini: {e}")
        else:
            if genai is None:
                print("[LLMExplanationAgent] google-generativeai not installed; using fallback explanations.")
            else:
                print("[LLMExplanationAgent] GEMINI_API_KEY not set; using fallback explanations.")

    def explain(self, report: ProviderReport) -> str:
        """
        Returns a short explanation string.
        - For 'needs_review' providers, we try LLM first, then fallback.
        - For others, a simple 'no manual review required' message.
        """
        if report.status != "needs_review":
            return "No manual review required. All fields validated with sufficient confidence."

        # First try LLM if configured
        if self._llm_ready:
            text = self._generate_explanation_llm(report)
            if text:
                return text

        # Fallback if LLM not available or failed
        return self._fallback_explanation(report)

    def _fallback_explanation(self, report: ProviderReport) -> str:
        reasons_text = "; ".join(report.reasons) if report.reasons else "No specific reasons logged."
        return (
            "This provider has been prioritized for manual review due to: "
            f"{reasons_text}. Please verify the provider's contact information "
            "and credentials using trusted internal systems (e.g., internal provider master, "
            "credentialing systems) or direct outreach before updating the directory."
        )

    def _generate_explanation_llm(self, report: ProviderReport) -> Optional[str]:
        """
        Actual Gemini call using the problem-statement context:
        - Focus on provider directory accuracy for a healthcare payer.
        - Explain in 2–3 bullet points:
          * Why it's flagged
          * Suggested next actions
        """
        if not self._model:
            return None

        provider = report.provider_input
        output = report.provider_output

        prompt = f"""
You are an assistant helping a healthcare payer's Provider Data Management and Network Operations team
to maintain accurate provider directories.

The goal is to:
- Detect incorrect or outdated provider contact information
- Reduce manual verification time
- Prioritize providers for manual review based on member impact and data quality

You are given a structured provider validation report. In 2–3 concise bullet points:
1) Explain why this provider has been flagged for manual review.
2) Suggest the most important next actions for the human reviewer.

Keep the language business-friendly and specific, not generic.

Provider input (from payer directory):
- Name: {provider.name}
- NPI: {provider.npi}
- Mobile: {provider.mobile_no}
- Address: {provider.address}
- Speciality: {provider.speciality}
- Member impact (1-5): {provider.member_impact}

Final validated output (after NPI registry + website checks):
- Name: {output.name.value} (confidence {output.name.confidence:.2f}, note: {output.name.note})
- NPI: {output.npi.value} (confidence {output.npi.confidence:.2f}, note: {output.npi.note})
- Mobile: {output.mobile_no.value} (confidence {output.mobile_no.confidence:.2f}, note: {output.mobile_no.note})
- Address: {output.address.value} (confidence {output.address.confidence:.2f}, note: {output.address.note})
- Speciality: {output.speciality.value} (confidence {output.speciality.confidence:.2f}, note: {output.speciality.note})

System classification:
- Status: {report.status}
- Reasons: {report.reasons}
- Priority level: {report.priority_level}
- Priority score: {report.priority_score:.2f}

Now respond with ONLY 2–3 bullet points, no extra preamble.
Each bullet should clearly state an issue and a recommended action.
""".strip()

        try:
            response = self._model.generate_content(prompt)
            text = getattr(response, "text", None)
            if not text:
                return None
            return text.strip()
        except Exception as e:
            print(f"[LLMExplanationAgent] Error calling Gemini: {e}")
            return None
